/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practico7.modelo;

/**
 *
 * @author noctu
 */
public class SuiteTematica  extends HabitacionHotel {
    
    private String tematicaDecoracion;

    public SuiteTematica() {
    }

    public SuiteTematica(String tematicaDecoracion, int numeroHabitacion, double precioNocheBase, boolean ocupada) {
        super(numeroHabitacion, precioNocheBase, ocupada);
        this.tematicaDecoracion = tematicaDecoracion;
    }

    
    public void setTematicaDecoracion(String tematicaDecoracion) {
        this.tematicaDecoracion = tematicaDecoracion;
    }

    public String getTematicaDecoracion() {
        return tematicaDecoracion;
    }

    @Override
    public String toString() {
        return "SuiteTematica{" + "tematicaDecoracion=" + tematicaDecoracion + '}';
    }
    
    
    public void calcularCostoEstadia(int noches){};
    
    public void iniciarCcicloDesinfeccion(){};
    
    public void pbtenerReporteSeguridad(){};

    @Override
    public void obtenerReporteSeguridad() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
    
    
    
    
}
