/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practico7.modelo;

/**
 *
 * @author noctu
 */
public class HabitacionEstandar extends HabitacionHotel {
    
    private int camaSupletorias;

    public HabitacionEstandar() {
    }

    public HabitacionEstandar(int camaSupletorias, int numeroHabitacion, double precioNocheBase, boolean ocupada) {
        super(numeroHabitacion, precioNocheBase, ocupada);
        this.camaSupletorias = camaSupletorias;
    }

   

    public void setCamaSupletorias(int camaSupletorias) {
        this.camaSupletorias = camaSupletorias;
    }

    public int getCamaSupletorias() {
        return camaSupletorias;
    }

    @Override
    public String toString() {
        return "HabitacionEstandar{" + "camaSupletorias=" + camaSupletorias + '}';
    }
    
    public void calcularCostoEstadia(int noches){};
    
    public void solicitarToallasExtra(){};

    @Override
    public void iniciarCcicloDesinfeccion() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void obtenerReporteSeguridad() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
    
    
}
