/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practico7.modelo;

/**
 *
 * @author noctu
 */
public class SuitePenthouse  extends HabitacionHotel {
   
    private boolean jacuzziPrivado;
    private ServicioMayordomo mayordomoVIP;

    public SuitePenthouse() {
    }

    public SuitePenthouse(boolean jacuzziPrivado, ServicioMayordomo mayordomoVIP, int numeroHabitacion, double precioNocheBase, boolean ocupada) {
        super(numeroHabitacion, precioNocheBase, ocupada);
        this.jacuzziPrivado = jacuzziPrivado;
        this.mayordomoVIP = mayordomoVIP;
    }

   

    public void setJacuzziPrivado(boolean jacuzziPrivado) {
        this.jacuzziPrivado = jacuzziPrivado;
    }

    public void setMayordomoVIP(ServicioMayordomo mayordomoVIP) {
        this.mayordomoVIP = mayordomoVIP;
    }

    public boolean isJacuzziPrivado() {
        return jacuzziPrivado;
    }

    public ServicioMayordomo getMayordomoVIP() {
        return mayordomoVIP;
    }

    @Override
    public String toString() {
        return "SuitePenthouse{" + "jacuzziPrivado=" + jacuzziPrivado + ", mayordomoVIP=" + mayordomoVIP + '}';
    }
    
    public void calcularCostoEstadia(int noches){};
    
    public void solicitarCenaGourmet(){};

    @Override
    public void iniciarCcicloDesinfeccion() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void obtenerReporteSeguridad() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
    
    
}
