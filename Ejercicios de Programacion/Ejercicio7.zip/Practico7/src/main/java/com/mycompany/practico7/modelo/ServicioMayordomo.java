/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practico7.modelo;

/**
 *
 * @author noctu
 */
public class ServicioMayordomo {
    
    private String nombreMayordomo;
    private int turnoDisponible;

    public ServicioMayordomo() {
    }

    public ServicioMayordomo(String nombreMayordomo, int turnoDisponible) {
        this.nombreMayordomo = nombreMayordomo;
        this.turnoDisponible = turnoDisponible;
    }

    public void setNombreMayordomo(String nombreMayordomo) {
        this.nombreMayordomo = nombreMayordomo;
    }

    public void setTurnoDisponible(int turnoDisponible) {
        this.turnoDisponible = turnoDisponible;
    }

    public String getNombreMayordomo() {
        return nombreMayordomo;
    }

    public int getTurnoDisponible() {
        return turnoDisponible;
    }

    @Override
    public String toString() {
        return "ServicioMayordomo{" + "nombreMayordomo=" + nombreMayordomo + ", turnoDisponible=" + turnoDisponible + '}';
    }
  
    public void atendrLlamadaVIP(){};
    
    
    
    
    
    
}
