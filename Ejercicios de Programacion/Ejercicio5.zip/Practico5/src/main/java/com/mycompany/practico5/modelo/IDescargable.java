/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.practico5.modelo;

/**
 *
 * @author noctu
 */
public interface IDescargable {
    
    void descargar();
    
    
    
}
