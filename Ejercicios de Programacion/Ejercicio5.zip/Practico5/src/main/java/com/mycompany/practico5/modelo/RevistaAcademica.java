/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practico5.modelo;

/**
 *
 * @author noctu
 */
public class RevistaAcademica extends RecursoBiblioteca {
    
    private int numeroEdicion;
    private String doiLicencia;

    public RevistaAcademica() {
    }

    public RevistaAcademica(int numeroEdicion, String doiLicencia) {
        this.numeroEdicion = numeroEdicion;
        this.doiLicencia = doiLicencia;
    }

   

    public void setNumeroEdicion(int numeroEdicion) {
        this.numeroEdicion = numeroEdicion;
    }

    public void setDoiLicencia(String doiLicencia) {
        this.doiLicencia = doiLicencia;
    }

    public int getNumeroEdicion() {
        return numeroEdicion;
    }

    public String getDoiLicencia() {
        return doiLicencia;
    }

    @Override
    public String toString() {
        return "RevistaAcademica{" + "numeroEdicion=" + numeroEdicion + ", doiLicencia=" + doiLicencia + '}';
    }
    
    public void descargar(){};
    
    
    
    
    
    
    
    
}
