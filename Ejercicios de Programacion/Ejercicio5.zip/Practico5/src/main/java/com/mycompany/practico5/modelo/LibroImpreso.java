/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practico5.modelo;

/**
 *
 * @author noctu
 */
public class LibroImpreso extends RecursoBiblioteca {
    
    private int numPaginas;
    private String tipoEmpastado;

    public LibroImpreso() {
    }

    public LibroImpreso(int numPaginas, String tipoEmpastado) {
        this.numPaginas = numPaginas;
        this.tipoEmpastado = tipoEmpastado;
    }

    
    
    
    public void setNumPaginas(int numPaginas) {
        this.numPaginas = numPaginas;
    }

    public void setTipoEmpastado(String tipoEmpastado) {
        this.tipoEmpastado = tipoEmpastado;
    }

    public int getNumPaginas() {
        return numPaginas;
    }

    public String getTipoEmpastado() {
        return tipoEmpastado;
    }

    @Override
    public String toString() {
        return "LibroImpreso{" + "numPaginas=" + numPaginas + ", tipoEmpastado=" + tipoEmpastado + '}';
    }
    
    public void hojearPaginas(){};

    @Override
    public void descargar() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
    
    
    
    
}
