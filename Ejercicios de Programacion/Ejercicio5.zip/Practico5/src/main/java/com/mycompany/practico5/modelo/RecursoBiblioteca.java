/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practico5.modelo;

/**
 *
 * @author noctu
 */
public abstract class RecursoBiblioteca implements IDescargable {
    
    private String id;
    private String titulo;
    private boolean disponibles;

    public RecursoBiblioteca() {
    }

    public RecursoBiblioteca(String id, String titulo, boolean disponible) {
        this.id = id;
        this.titulo = titulo;
        this.disponibles = disponible;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setDisponible(boolean disponible) {
        this.disponibles = disponible;
    }

    public String getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public boolean isDisponible() {
        return disponibles;
    }

    @Override
    public String toString() {
        return "RecursoBiblioteca{" + "id=" + id + ", titulo=" + titulo + ", disponible=" + disponibles + '}';
    }
    
    public void prestar(){};
    
    public void devolver(){};
    
    public void isDisponibles(){};
    
    
    
    
    
    
}
