/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practico10.modelo;

/**
 *
 * @author noctu
 */
public class TanquePresurizadoAgro {
    
    private double capacidadLitrosPesticida;
    private boolean boquillaAntideriva;

    public TanquePresurizadoAgro() {
    }

    public TanquePresurizadoAgro(double capacidadLitrosPesticida, boolean boquillaAntideriva) {
        this.capacidadLitrosPesticida = capacidadLitrosPesticida;
        this.boquillaAntideriva = boquillaAntideriva;
    }

    public void setCapacidadLitrosPesticida(double capacidadLitrosPesticida) {
        this.capacidadLitrosPesticida = capacidadLitrosPesticida;
    }

    public void setBoquillaAntideriva(boolean boquillaAntideriva) {
        this.boquillaAntideriva = boquillaAntideriva;
    }

    public double getCapacidadLitrosPesticida() {
        return capacidadLitrosPesticida;
    }

    public boolean isBoquillaAntideriva() {
        return boquillaAntideriva;
    }

    @Override
    public String toString() {
        return "TanquePresurizadoAgro{" + "capacidadLitrosPesticida=" + capacidadLitrosPesticida + ", boquillaAntideriva=" + boquillaAntideriva + '}';
    }
    
    public void purgaSistemaBoquillas(){};
    
    
    
    
    
}
