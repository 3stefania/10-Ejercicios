/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practico10.modelo;

/**
 *
 * @author noctu
 */
public class DronMultiespectral extends DispositivoAgricola  {
 
    private int bandasEsprectales;

    public DronMultiespectral() {
    }

    public DronMultiespectral(int bandasEsprectales, String idDispositivo, double hectareasCobertura, int bateriaRestante) {
        super(idDispositivo, hectareasCobertura, bateriaRestante);
        this.bandasEsprectales = bandasEsprectales;
    }


    public void setBandasEsprectales(int bandasEsprectales) {
        this.bandasEsprectales = bandasEsprectales;
    }

    public int getBandasEsprectales() {
        return bandasEsprectales;
    }

    @Override
    public String toString() {
        return "DronMultiespectral{" + "bandasEsprectales=" + bandasEsprectales + '}';
    }
    
    public void ejecutarCicloLaboral(){};
    
    public void calcularIndiceVigorVegetal(){};
    
    public void generarMapaEstresHidrico(){};
    
    
    
    
    
    
    
}
