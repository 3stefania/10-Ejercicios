/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practico10.modelo;

/**
 *
 * @author noctu
 */
public abstract class DispositivoAgricola implements IAnalizableNDVI{
    
    private String idDispositivo;
    private double hectareasCobertura;
    private int bateriaRestante;

    public DispositivoAgricola() {
    }

    public DispositivoAgricola(String idDispositivo, double hectareasCobertura, int bateriaRestante) {
        this.idDispositivo = idDispositivo;
        this.hectareasCobertura = hectareasCobertura;
        this.bateriaRestante = bateriaRestante;
    }

    public void setIdDispositivo(String idDispositivo) {
        this.idDispositivo = idDispositivo;
    }

    public void setHectareasCobertura(double hectareasCobertura) {
        this.hectareasCobertura = hectareasCobertura;
    }

    public void setBateriaRestante(int bateriaRestante) {
        this.bateriaRestante = bateriaRestante;
    }

    public String getIdDispositivo() {
        return idDispositivo;
    }

    public double getHectareasCobertura() {
        return hectareasCobertura;
    }

    public int getBateriaRestante() {
        return bateriaRestante;
    }

    @Override
    public String toString() {
        return "DispositivoAgricola{" + "idDispositivo=" + idDispositivo + ", hectareasCobertura=" + hectareasCobertura + ", bateriaRestante=" + bateriaRestante + '}';
    }
    
    public void ejecutarCicloLaboral(){};
    
    public void reportarEstadoBateria(){};
    
    
    
    
    
    
    
    
    
}
