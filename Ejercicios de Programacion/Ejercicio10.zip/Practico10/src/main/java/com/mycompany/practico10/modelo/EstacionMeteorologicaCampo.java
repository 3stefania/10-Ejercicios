/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practico10.modelo;

/**
 *
 * @author noctu
 */
public class EstacionMeteorologicaCampo extends DispositivoAgricola {
 
    private double sensorPluviometroMm;
    private double presionarBarometricaHPa;

    public EstacionMeteorologicaCampo() {
    }

    public EstacionMeteorologicaCampo(double sensorPluviometroMm, double presionarBarometricaHPa, String idDispositivo, double hectareasCobertura, int bateriaRestante) {
        super(idDispositivo, hectareasCobertura, bateriaRestante);
        this.sensorPluviometroMm = sensorPluviometroMm;
        this.presionarBarometricaHPa = presionarBarometricaHPa;
    }


    public void setSensorPluviometroMm(double sensorPluviometroMm) {
        this.sensorPluviometroMm = sensorPluviometroMm;
    }

    public void setPresionarBarometricaHPa(double presionarBarometricaHPa) {
        this.presionarBarometricaHPa = presionarBarometricaHPa;
    }

    public double getSensorPluviometroMm() {
        return sensorPluviometroMm;
    }

    public double getPresionarBarometricaHPa() {
        return presionarBarometricaHPa;
    }

    @Override
    public String toString() {
        return "EstacionMeteorologicaCampo{" + "sensorPluviometroMm=" + sensorPluviometroMm + ", presionarBarometricaHPa=" + presionarBarometricaHPa + '}';
    }
    
    public void ejecutarCicloLaboral(){};
    
    public void predecirRiesgoHelada(){};

    @Override
    public void calcularIndiceVigorVegetal() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void generarMapaEstresHidrico() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
    
    
    
    
    
}
