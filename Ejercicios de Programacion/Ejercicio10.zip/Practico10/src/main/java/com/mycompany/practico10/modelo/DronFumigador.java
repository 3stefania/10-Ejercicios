/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practico10.modelo;

/**
 *
 * @author noctu
 */
public class DronFumigador extends DispositivoAgricola {
    
    private double caudalLitrosPorMinuto;
    private TanquePresurizadoAgro tanqueQuimico;

    public DronFumigador() {
    }

    public DronFumigador(double caudalLitrosPorMinuto, TanquePresurizadoAgro tanqueQuimico, String idDispositivo, double hectareasCobertura, int bateriaRestante) {
        super(idDispositivo, hectareasCobertura, bateriaRestante);
        this.caudalLitrosPorMinuto = caudalLitrosPorMinuto;
        this.tanqueQuimico = tanqueQuimico;
    }

   public void setCaudalLitrosPorMinuto(double caudalLitrosPorMinuto) {
        this.caudalLitrosPorMinuto = caudalLitrosPorMinuto;
    }

    public void setTanqueQuimico(TanquePresurizadoAgro tanqueQuimico) {
        this.tanqueQuimico = tanqueQuimico;
    }

    public double getCaudalLitrosPorMinuto() {
        return caudalLitrosPorMinuto;
    }

    public TanquePresurizadoAgro getTanqueQuimico() {
        return tanqueQuimico;
    }

    @Override
    public String toString() {
        return "DronFumigador{" + "caudalLitrosPorMinuto=" + caudalLitrosPorMinuto + ", tanqueQuimico=" + tanqueQuimico + '}';
    }
    
    public void ejecutarCicloLaboral(){};
    
    public void iniciarAspersionUniforme(){};

    @Override
    public void calcularIndiceVigorVegetal() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void generarMapaEstresHidrico() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
    
    
    
}
