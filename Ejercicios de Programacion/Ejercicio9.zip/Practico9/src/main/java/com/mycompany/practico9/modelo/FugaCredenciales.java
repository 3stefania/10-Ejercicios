/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practico9.modelo;

/**
 *
 * @author noctu
 */
public class FugaCredenciales extends IncidenteSeguridad {
    
    private int cantidadCuentasComprometidas;

    public FugaCredenciales() {
    }

    public FugaCredenciales(int cantidadCuentasComprometidas, String idAlerta, String direccionIPOrigen, String nivelSeveridad) {
        super(idAlerta, direccionIPOrigen, nivelSeveridad);
        this.cantidadCuentasComprometidas = cantidadCuentasComprometidas;
    }

    

    public void setCantidadCuentasComprometidas(int cantidadCuentasComprometidas) {
        this.cantidadCuentasComprometidas = cantidadCuentasComprometidas;
    }

    public int getCantidadCuentasComprometidas() {
        return cantidadCuentasComprometidas;
    }

    @Override
    public String toString() {
        return "FugaCredenciales{" + "cantidadCuentasComprometidas=" + cantidadCuentasComprometidas + '}';
    }
    
    public void mitigarAmenaza(){};
    
    public void exportarFormatoSyslog(){};
    
    public void calcularPuntajeRiesgo(){};
    
    
    
    
    
    
    
}
