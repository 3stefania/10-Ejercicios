/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.practico9;

/**
 *
 * @author noctu
 */
public class Practico9 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
