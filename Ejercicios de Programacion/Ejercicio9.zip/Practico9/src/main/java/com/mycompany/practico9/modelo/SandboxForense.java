/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practico9.modelo;

/**
 *
 * @author noctu
 */
public class SandboxForense {
    
    private String sistemaOperativoVirtual;
    private boolean entornoAisladoActivo;

    public SandboxForense() {
    }

    public SandboxForense(String sistemaOperativoVirtual, boolean entornoAisladoActivo) {
        this.sistemaOperativoVirtual = sistemaOperativoVirtual;
        this.entornoAisladoActivo = entornoAisladoActivo;
    }

    public void setSistemaOperativoVirtual(String sistemaOperativoVirtual) {
        this.sistemaOperativoVirtual = sistemaOperativoVirtual;
    }

    public void setEntornoAisladoActivo(boolean entornoAisladoActivo) {
        this.entornoAisladoActivo = entornoAisladoActivo;
    }

    public String getSistemaOperativoVirtual() {
        return sistemaOperativoVirtual;
    }

    public boolean isEntornoAisladoActivo() {
        return entornoAisladoActivo;
    }

    @Override
    public String toString() {
        return "SandboxForense{" + "sistemaOperativoVirtual=" + sistemaOperativoVirtual + ", entornoAisladoActivo=" + entornoAisladoActivo + '}';
    }
    
    public void detonarMuestraSospechosa(){};
    
    
    
    
    
    
    
    
    
    
}
