/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practico8.modelo;

/**
 *
 * @author noctu
 */
public class PlatoPrincipal extends PlatilloMenu {
 
    private String tipoProteina;
    private Sommelier sommelierAsignado;

    public PlatoPrincipal() {
    }

    public PlatoPrincipal(String tipoProteina, Sommelier sommelierAsignado, String idPlato, String nombre, double precioBase) {
        super(idPlato, nombre, precioBase);
        this.tipoProteina = tipoProteina;
        this.sommelierAsignado = sommelierAsignado;
    }


    public void setTipoProteina(String tipoProteina) {
        this.tipoProteina = tipoProteina;
    }

    public void setSommelierAsignado(Sommelier sommelierAsignado) {
        this.sommelierAsignado = sommelierAsignado;
    }

    public String getTipoProteina() {
        return tipoProteina;
    }

    public Sommelier getSommelierAsignado() {
        return sommelierAsignado;
    }

    @Override
    public String toString() {
        return "PlatoPrincipal{" + "tipoProteina=" + tipoProteina + ", sommelierAsignado=" + sommelierAsignado + '}';
    }
    
    
    
    public void calcularPrecioFinal(){};
    
    public void sugerirMaridaje(){};

    @Override
    public void sellarEmpaque() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void tiempoConservacionMin() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
    
    
}
