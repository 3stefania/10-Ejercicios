/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practico8.modelo;

/**
 *
 * @author noctu
 */
public class EntradaGourmet extends PlatilloMenu {
 
    private boolean esFrio;

    public EntradaGourmet() {
    }

    public EntradaGourmet(boolean esFrio, String idPlato, String nombre, double precioBase) {
        super(idPlato, nombre, precioBase);
        this.esFrio = esFrio;
    }

    

    public void setEsFrio(boolean esFrio) {
        this.esFrio = esFrio;
    }

    public boolean isEsFrio() {
        return esFrio;
    }

    @Override
    public String toString() {
        return "EntradaGourmet{" + "esFrio=" + esFrio + '}';
    }
    
    public void calcularPrecioFinal(){};
    
    public void verificarAlergenos(){};

    @Override
    public void sellarEmpaque() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void tiempoConservacionMin() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
    
    
}
