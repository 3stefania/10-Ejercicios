/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practico8.modelo;

/**
 *
 * @author noctu
 */
public class PedidosDelivery  extends PlatilloMenu {
    
    private String direccionEntrega;

    public PedidosDelivery() {
    }

    public PedidosDelivery(String direccionEntrega, String idPlato, String nombre, double precioBase) {
        super(idPlato, nombre, precioBase);
        this.direccionEntrega = direccionEntrega;
    }


    public void setDireccionEntrega(String direccionEntrega) {
        this.direccionEntrega = direccionEntrega;
    }

    public String getDireccionEntrega() {
        return direccionEntrega;
    }

    @Override
    public String toString() {
        return "PedidosDelivery{" + "direccionEntrega=" + direccionEntrega + '}';
    }
    
    public void calcularPrecioFinal(){};
    
    public void sellaEmpaque(){};
    
    public void tiempoConservacionMin(){};

    @Override
    public void sellarEmpaque() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
    
    
}
