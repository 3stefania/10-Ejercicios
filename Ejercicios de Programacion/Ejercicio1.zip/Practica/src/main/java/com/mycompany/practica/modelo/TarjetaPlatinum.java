/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practica.modelo;

/**
 *
 * @author noctu
 */
public class TarjetaPlatinum extends CuentaBancaria {
    
    private double cupoDolares;

    public TarjetaPlatinum() {
    }

    public TarjetaPlatinum(double cupoDolares, String numeroCuenta, double saldoActual, String titular) {
        super(numeroCuenta, saldoActual, titular);
        this.cupoDolares = cupoDolares;
    }

   

    public void setCupoDolares(double cupoDolares) {
        this.cupoDolares = cupoDolares;
    }

    public double getCupoDolares() {
        return cupoDolares;
    }

    @Override
    public String toString() {
        return "TarjetaPlatinum{" + "cupoDolares=" + cupoDolares + '}';
    }
    
    public void validarPIN(String pin){ };
    
    public void retirarEfectivoATM(double monto){ };

    @Override
    public void retirarEfectivo(double monto) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

  



}
    
    
    
    
    

