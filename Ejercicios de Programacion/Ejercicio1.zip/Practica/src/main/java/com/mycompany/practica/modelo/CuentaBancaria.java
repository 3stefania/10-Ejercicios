/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practica.modelo;

/**
 *
 * @author noctu
 */
public abstract class CuentaBancaria implements OperableCajeroInterface {
    
    private String numeroCuenta;
    private double saldoActual;
    private String titular;

    public CuentaBancaria() {
    }

    public CuentaBancaria(String numeroCuenta, double saldoActual, String titular) {
        this.numeroCuenta = numeroCuenta;
        this.saldoActual = saldoActual;
        this.titular = titular;
    }

    public void setNumeroCuenta(String numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public void setSaldoActual(double saldoActual) {
        this.saldoActual = saldoActual;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public double getSaldoActual() {
        return saldoActual;
    }

    public String getTitular() {
        return titular;
    }

    @Override
    public String toString() {
        return "CuentaBancaria{" + "numeroCuenta=" + numeroCuenta + ", saldoActual=" + saldoActual + ", titular=" + titular + '}';
    }
    
    public void depositar(double monto){};
    
    public void retirar(double monto){};
    
}
