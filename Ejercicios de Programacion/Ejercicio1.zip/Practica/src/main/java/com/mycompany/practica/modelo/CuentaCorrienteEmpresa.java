/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practica.modelo;

/**
 *
 * @author noctu
 */
public class CuentaCorrienteEmpresa extends CuentaBancaria {
    
private  double cupoSobregiro;
private OficialCredito ejecutivo;

    public CuentaCorrienteEmpresa() {
    }


    public CuentaCorrienteEmpresa(double cupoSobregiro, OficialCredito ejecutivo, String numeroCuenta, double saldoActual, String titular) {
        super(numeroCuenta, saldoActual, titular);
        this.cupoSobregiro = cupoSobregiro;
        this.ejecutivo = ejecutivo;
    }

    public void setCupoSobregiro(double cupoSobregiro) {
        this.cupoSobregiro = cupoSobregiro;
    }

    public void setEjecutivo(OficialCredito ejecutivo) {
        this.ejecutivo = ejecutivo;
    }

    public double getCupoSobregiro() {
        return cupoSobregiro;
    }

    public OficialCredito getEjecutivo() {
        return ejecutivo;
    }

    @Override
    public String toString() {
        return "CuentaCorrienteEmpresa{" + "cupoSobregiro=" + cupoSobregiro + ", ejecutivo=" + ejecutivo + '}';
    }

public void retirar(double monto){};

public void solicitarGiroEspecial() {};

    @Override
    public void validarPIN(String pin) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void retirarEfectivo(double monto) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }





}
