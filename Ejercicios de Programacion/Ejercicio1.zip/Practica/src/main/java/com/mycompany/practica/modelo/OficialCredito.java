/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practica.modelo;

/**
 *
 * @author noctu
 */
public class OficialCredito {
    
    private String nombreOficial;
    private double limiteAprobacionUSD;

    public OficialCredito() {
    }

    public OficialCredito(String nombreOficial, double limiteAprobacionUSD) {
        this.nombreOficial = nombreOficial;
        this.limiteAprobacionUSD = limiteAprobacionUSD;
    }

    public void setNombreOficial(String nombreOficial) {
        this.nombreOficial = nombreOficial;
    }

    public void setLimiteAprobacionUSD(double limiteAprobacionUSD) {
        this.limiteAprobacionUSD = limiteAprobacionUSD;
    }

    public String getNombreOficial() {
        return nombreOficial;
    }

    public double getLimiteAprobacionUSD() {
        return limiteAprobacionUSD;
    }

    @Override
    public String toString() {
        return "OficialCredito{" + "nombreOficial=" + nombreOficial + ", limiteAprobacionUSD=" + limiteAprobacionUSD + '}';
    }
    
    
    
    
    
    
    
    
}
