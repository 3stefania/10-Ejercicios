/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practica.modelo;

/**
 *
 * @author noctu
 */
public class CuentaAhorro extends CuentaBancaria {
    
    private double tasaInteresAnual;

    public CuentaAhorro() {
    }

    public CuentaAhorro(double tasaInteresAnual, String numeroCuenta, double saldoActual, String titular) {
        super(numeroCuenta, saldoActual, titular);
        this.tasaInteresAnual = tasaInteresAnual;
    }

    

    public void setTasaInteresAnual(double tasaInteresAnual) {
        this.tasaInteresAnual = tasaInteresAnual;
    }

    public double getTasaInteresAnual() {
        return tasaInteresAnual;
    }

    @Override
    public String toString() {
        return "CuentaAhorro{" + "tasaInteresAnual=" + tasaInteresAnual + '}';
    }

   public void retirar(double monto){};
   
   public void abonarInteresesMensuales(){};

    @Override
    public void validarPIN(String pin) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void retirarEfectivo(double monto) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    





}
