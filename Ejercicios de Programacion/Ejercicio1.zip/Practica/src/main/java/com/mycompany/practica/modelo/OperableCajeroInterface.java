/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.practica.modelo;

/**
 *
 * @author noctu
 */
public interface OperableCajeroInterface {
    
    void validarPIN(String pin);
    void retirarEfectivo (double monto);
    
    
    
}
