/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practica3.modelo;

/**
 *
 * @author noctu
 */
public class MantencionPreventiva {
    
    private boolean cambioFiltrosIncluido;

    public MantencionPreventiva() {
    }

    public MantencionPreventiva(boolean cambioFiltrosIncluido) {
        this.cambioFiltrosIncluido = cambioFiltrosIncluido;
    }

    public void setCambioFiltrosIncluido(boolean cambioFiltrosIncluido) {
        this.cambioFiltrosIncluido = cambioFiltrosIncluido;
    }

    public boolean isCambioFiltrosIncluido() {
        return cambioFiltrosIncluido;
    }

    @Override
    public String toString() {
        return "MantencionPreventiva{" + "cambioFiltrosIncluido=" + cambioFiltrosIncluido + '}';
    }
    
    public void calcularCostoTotal(){};
    public void rellenarFluidoFrenos(){};
    
    
    
    
    
    
    
    
}
