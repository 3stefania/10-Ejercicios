/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practica3.modelo;

/**
 *
 * @author noctu
 */
public abstract class ServicioMecanico implements GarantizableTallerInterface {
    
    private String idOrden;
    private String pateneteVehiculo;
    private double manoObraBase;

    public ServicioMecanico() {
    }

    public ServicioMecanico(String idOrden, String pateneteVehiculo, double manoObraBase) {
        this.idOrden = idOrden;
        this.pateneteVehiculo = pateneteVehiculo;
        this.manoObraBase = manoObraBase;
    }

    public void setIdOrden(String idOrden) {
        this.idOrden = idOrden;
    }

    public void setPateneteVehiculo(String pateneteVehiculo) {
        this.pateneteVehiculo = pateneteVehiculo;
    }

    public void setManoObraBase(double manoObraBase) {
        this.manoObraBase = manoObraBase;
    }

    public String getIdOrden() {
        return idOrden;
    }

    public String getPateneteVehiculo() {
        return pateneteVehiculo;
    }

    public double getManoObraBase() {
        return manoObraBase;
    }

    @Override
    public String toString() {
        return "ServicioMecanico{" + "idOrden=" + idOrden + ", pateneteVehiculo=" + pateneteVehiculo + ", manoObraBase=" + manoObraBase + '}';
    }
    
    public void calcularCostoTotal(){};
    public void finalizarServicio(){};
    
    
    
    
    
    
}
