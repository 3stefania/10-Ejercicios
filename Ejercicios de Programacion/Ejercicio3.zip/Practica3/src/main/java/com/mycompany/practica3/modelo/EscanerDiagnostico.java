/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practica3.modelo;

/**
 *
 * @author noctu
 */
public class EscanerDiagnostico {
    
    private String marcarEscaner;
    private String versionSotfware;

    public EscanerDiagnostico() {
    }

    public EscanerDiagnostico(String marcarEscaner, String versionSotfware) {
        this.marcarEscaner = marcarEscaner;
        this.versionSotfware = versionSotfware;
    }

    public void setMarcarEscaner(String marcarEscaner) {
        this.marcarEscaner = marcarEscaner;
    }

    public void setVersionSotfware(String versionSotfware) {
        this.versionSotfware = versionSotfware;
    }

    public String getMarcarEscaner() {
        return marcarEscaner;
    }

    public String getVersionSotfware() {
        return versionSotfware;
    }

    @Override
    public String toString() {
        return "EscanerDiagnostico{" + "marcarEscaner=" + marcarEscaner + ", versionSotfware=" + versionSotfware + '}';
    }
    
    public void leerCodigoFallaOBD2(){};
    
    
    
    
}
