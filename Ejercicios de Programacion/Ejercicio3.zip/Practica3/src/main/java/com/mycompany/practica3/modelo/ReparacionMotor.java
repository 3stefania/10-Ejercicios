/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practica3.modelo;

/**
 *
 * @author noctu
 */
public class ReparacionMotor {
    
    private double horasTrabajoMecanico;
    private EscanerDiagnostico escanerOBD;

    public ReparacionMotor() {
    }

    public ReparacionMotor(double horasTrabajoMecanico, EscanerDiagnostico escanerOBD) {
        this.horasTrabajoMecanico = horasTrabajoMecanico;
        this.escanerOBD = escanerOBD;
    }

    public void setHorasTrabajoMecanico(double horasTrabajoMecanico) {
        this.horasTrabajoMecanico = horasTrabajoMecanico;
    }

    public void setEscanerOBD(EscanerDiagnostico escanerOBD) {
        this.escanerOBD = escanerOBD;
    }

    public double getHorasTrabajoMecanico() {
        return horasTrabajoMecanico;
    }

    public EscanerDiagnostico getEscanerOBD() {
        return escanerOBD;
    }

    @Override
    public String toString() {
        return "ReparacionMotor{" + "horasTrabajoMecanico=" + horasTrabajoMecanico + ", escanerOBD=" + escanerOBD + '}';
    }
    
    public void calcularCostaTotal(){};
    public void escanerComputadorVehiculo(){};
    
    
    
}
