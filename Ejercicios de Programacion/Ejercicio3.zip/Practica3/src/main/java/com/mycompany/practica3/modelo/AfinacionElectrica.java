/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practica3.modelo;

/**
 *
 * @author noctu
 */
public class AfinacionElectrica {
    
    private int repuestosCambiados;

    public AfinacionElectrica() {
    }

    public AfinacionElectrica(int repuestosCambiados) {
        this.repuestosCambiados = repuestosCambiados;
    }

    public void setRepuestosCambiados(int repuestosCambiados) {
        this.repuestosCambiados = repuestosCambiados;
    }

    public int getRepuestosCambiados() {
        return repuestosCambiados;
    }

    @Override
    public String toString() {
        return "AfinacionElectrica{" + "repuestosCambiados=" + repuestosCambiados + '}';
    }
    
    public void calcularCostoTotal(){};
    
    public void emitirCertificadoGarantia(int meses){};
    
    public void validarEstadoPiezasOriginales(){};
    
    
    
    
    
    
    
    
}
