/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.practico6.modelo;

/**
 *
 * @author noctu
 */
public interface IFacturableDigital {
 
    
    void generarFacturaXML();
    
    void enviarPorCorreo(String email);
    
    
    
    
    
    
}
