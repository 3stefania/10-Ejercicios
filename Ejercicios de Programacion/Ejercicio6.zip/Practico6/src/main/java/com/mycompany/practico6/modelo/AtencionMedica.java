/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practico6.modelo;

/**
 *
 * @author noctu
 */
public abstract class AtencionMedica implements IFacturableDigital {
 
    private String codigoAtencion;
    private double costoBase;

    public AtencionMedica() {
    }

    public AtencionMedica(String codigoAtencion, double costoBase) {
        this.codigoAtencion = codigoAtencion;
        this.costoBase = costoBase;
    }

    public void setCodigoAtencion(String codigoAtencion) {
        this.codigoAtencion = codigoAtencion;
    }

    public void setCostoBase(double costoBase) {
        this.costoBase = costoBase;
    }

    public String getCodigoAtencion() {
        return codigoAtencion;
    }

    public double getCostoBase() {
        return costoBase;
    }

    @Override
    public String toString() {
        return "AtencionMedica{" + "codigoAtencion=" + codigoAtencion + ", costoBase=" + costoBase + '}';
    }
    
    
    public void calcularCostoTotal(){};
    
    public void registrarDiagnostico(String diag){};
    
    
    
}
