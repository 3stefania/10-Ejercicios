/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practico6.modelo;

/**
 *
 * @author noctu
 */
public class Telemedicina extends AtencionMedica {
    
    private String plataformaVideo;

    public Telemedicina() {
    }

    public Telemedicina(String plataformaVideo, String codigoAtencion, double costoBase) {
        super(codigoAtencion, costoBase);
        this.plataformaVideo = plataformaVideo;
    }


    public void setPlataformaVideo(String plataformaVideo) {
        this.plataformaVideo = plataformaVideo;
    }

    public String getPlataformaVideo() {
        return plataformaVideo;
    }

    @Override
    public String toString() {
        return "Telemedicina{" + "plataformaVideo=" + plataformaVideo + '}';
    }
    
    public void calcularCostoTotal(){};
    
    public void generarFacturaXML(){};
    
    public void enviarPorCorreo(String email){};
    
    
    
}
