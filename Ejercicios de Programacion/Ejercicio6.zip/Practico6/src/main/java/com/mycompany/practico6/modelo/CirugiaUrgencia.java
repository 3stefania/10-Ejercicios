/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practico6.modelo;

/**
 *
 * @author noctu
 */
public class CirugiaUrgencia extends AtencionMedica {
    
    private double horaDuracion;
    private Quirofano quirofanoAsignado;

    public CirugiaUrgencia() {
    }

    public CirugiaUrgencia(double horaDuracion, Quirofano quirofanoAsignado, String codigoAtencion, double costoBase) {
        super(codigoAtencion, costoBase);
        this.horaDuracion = horaDuracion;
        this.quirofanoAsignado = quirofanoAsignado;
    }

    
    
    public void setHoraDuracion(double horaDuracion) {
        this.horaDuracion = horaDuracion;
    }

    public void setQuirofanoAsignado(Quirofano quirofanoAsignado) {
        this.quirofanoAsignado = quirofanoAsignado;
    }

    public double getHoraDuracion() {
        return horaDuracion;
    }

    public Quirofano getQuirofanoAsignado() {
        return quirofanoAsignado;
    }

    @Override
    public String toString() {
        return "CirugiaUrgencia{" + "horaDuracion=" + horaDuracion + ", quirofanoAsignado=" + quirofanoAsignado + '}';
    }
    
    public void calcularCostoTotal(){};
    
    public void prepararEquipo(){};

    @Override
    public void generarFacturaXML() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void enviarPorCorreo(String email) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
    
    
    
    
    
    
    
}
