/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practica2.modelo;

/**
 *
 * @author noctu
 */
public class SobreDocumento extends PaqueteEnvio{
 
    private boolean esDocumentoLegal;

    public SobreDocumento() {
    }

    public SobreDocumento(boolean esDocumentoLegal) {
        this.esDocumentoLegal = esDocumentoLegal;
    }

    public void setEsDocumentoLegal(boolean esDocumentoLegal) {
        this.esDocumentoLegal = esDocumentoLegal;
    }

    public boolean isEsDocumentoLegal() {
        return esDocumentoLegal;
    }

    @Override
    public String toString() {
        return "SobreDocumento{" + "esDocumentoLegal=" + esDocumentoLegal + '}';
    }
    
    public void calcularCostoEnvio(){}
    public void marcarComoConfidencial(){};

    @Override
    public void cotizarPolizaSegruo() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void emitirCertificadoProteccion() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
}
