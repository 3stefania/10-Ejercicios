/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practica2.modelo;

/**
 *
 * @author noctu
 */
public class PaquetePesado extends PaqueteEnvio {
    
    private boolean esCargaPaletizada;
    private BasculaIndustrial basculaOficial;

    public PaquetePesado() {
    }

    public PaquetePesado(boolean esCargaPaletizada, BasculaIndustrial basculaOficial) {
        this.esCargaPaletizada = esCargaPaletizada;
        this.basculaOficial = basculaOficial;
    }

    public void setEsCargaPaletizada(boolean esCargaPaletizada) {
        this.esCargaPaletizada = esCargaPaletizada;
    }

    public void setBasculaOficial(BasculaIndustrial basculaOficial) {
        this.basculaOficial = basculaOficial;
    }

    public boolean isEsCargaPaletizada() {
        return esCargaPaletizada;
    }

    public BasculaIndustrial getBasculaOficial() {
        return basculaOficial;
    }

    @Override
    public String toString() {
        return "PaquetePesado{" + "esCargaPaletizada=" + esCargaPaletizada + ", basculaOficial=" + basculaOficial + '}';
    }
    
    public void calcularCostoEnvio(){};
    public void pesajeOficial(){};

    @Override
    public void cotizarPolizaSegruo() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void emitirCertificadoProteccion() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
    
    
    
    
    
}
