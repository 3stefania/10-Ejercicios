/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practica2.modelo;

/**
 *
 * @author noctu
 */
public class BasculaIndustrial {
    
    private double precisionGramos;
    private String fechaCertificado;

    public BasculaIndustrial() {
    }

    public BasculaIndustrial(double precisionGramos, String fechaCertificado) {
        this.precisionGramos = precisionGramos;
        this.fechaCertificado = fechaCertificado;
    }

    public void setPrecisionGramos(double precisionGramos) {
        this.precisionGramos = precisionGramos;
    }

    public void setFechaCertificado(String fechaCertificado) {
        this.fechaCertificado = fechaCertificado;
    }

    public double getPrecisionGramos() {
        return precisionGramos;
    }

    public String getFechaCertificado() {
        return fechaCertificado;
    }

    @Override
    public String toString() {
        return "BasculaIndustrial{" + "precisionGramos=" + precisionGramos + ", fechaCertificado=" + fechaCertificado + '}';
    }
    
    public void obtenerPesajePrecision(){};
    
    
    
    
    
}
