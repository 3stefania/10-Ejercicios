/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.practica2;

/**
 *
 * @author noctu
 */
public class Practica2 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
