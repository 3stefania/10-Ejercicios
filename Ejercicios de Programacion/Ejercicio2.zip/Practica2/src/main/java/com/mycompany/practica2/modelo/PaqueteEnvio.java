/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practica2.modelo;

/**
 *
 * @author noctu
 */
public abstract class PaqueteEnvio implements  AsegurableRiesgoInterface {
    
    private String numeroGuia;
    private double pesoKg;
    private String destino;

    public PaqueteEnvio() {
    }

    public PaqueteEnvio(String numeroGuia, double pesoKg, String destino) {
        this.numeroGuia = numeroGuia;
        this.pesoKg = pesoKg;
        this.destino = destino;
    }

    public String getNumeroGuia() {
        return numeroGuia;
    }

    public double getPesoKg() {
        return pesoKg;
    }

    public String getDestino() {
        return destino;
    }

    public void setNumeroGuia(String numeroGuia) {
        this.numeroGuia = numeroGuia;
    }

    public void setPesoKg(double pesoKg) {
        this.pesoKg = pesoKg;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    @Override
    public String toString() {
        return "PaqueteEnvio{" + "numeroGuia=" + numeroGuia + ", pesoKg=" + pesoKg + ", destino=" + destino + '}';
    }
    
    
    
    
    
    
    
    
}
