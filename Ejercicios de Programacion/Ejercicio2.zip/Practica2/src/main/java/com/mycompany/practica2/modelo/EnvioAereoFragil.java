/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practica2.modelo;

/**
 *
 * @author noctu
 */
public class EnvioAereoFragil extends PaqueteEnvio {
 
    private double valorDeclarado;

    public EnvioAereoFragil() {
    }

    public EnvioAereoFragil(double valorDeclarado) {
        this.valorDeclarado = valorDeclarado;
    }

    public void setValorDeclarado(double valorDeclarado) {
        this.valorDeclarado = valorDeclarado;
    }

    public double getValorDeclarado() {
        return valorDeclarado;
    }

    @Override
    public String toString() {
        return "EnvioAereoFragil{" + "valorDeclarado=" + valorDeclarado + '}';
    }
    
    public void calcularCostoEnvio(){};
    public void cotizarPolizaSeguro(){};
    public void emitirCertificadoProteccion(){};

    @Override
    public void cotizarPolizaSegruo() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
    
    
}
